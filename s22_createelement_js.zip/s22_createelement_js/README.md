# S22_CreateElement_JS

A Pen created on CodePen.

Original URL: [https://codepen.io/RICARDO-AMAROBERNARD/pen/WbwKzyd](https://codepen.io/RICARDO-AMAROBERNARD/pen/WbwKzyd).

